/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package assignment;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;
import static javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE;

/**
 *
 * @author Asus
 */
public class UpdateStaff extends javax.swing.JFrame {

    private String userTP1;
    private User userTP2;
    private String tpNumber;
    private String name;
    private String dateOfBirth;
    private String gender;
    private String email;
    private String password;
    private String role;
    private String roomType;
    private String Status;
    
    public String getTPNumber() {
        return tpNumber;
    }

    public void setTPNumber(String tpNumber) {
        if (tpNumber.matches("TP\\d{6}")) {
            this.tpNumber = tpNumber;
        } else if(tpNumber.equals("TP")){
            throw new IllegalArgumentException("TP Number cannot be empty.");
        } else{
            throw new IllegalArgumentException("Invalid TP Number format.");
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name.contains(",")) {
            throw new IllegalArgumentException("Name cannot contain ',' character.");
        } else if (!name.isEmpty()) {
            this.name = name;
        } else {
            throw new IllegalArgumentException("Name cannot be empty.");
        }
    }
    
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dobString) {
        if (dobString.isEmpty()){
            throw new IllegalArgumentException("Date of Birth cannot be empty");
        }
        if (!isValidDate(dobString)) {
            throw new IllegalArgumentException("Invalid date format or date is in the future.");
        }
        if (!ageChecker(dobString)) {
            throw new IllegalArgumentException("User must be at least 15 years old to register.");
        }
        this.dateOfBirth = dobString;
    }
    
    public String getGender() {
        return gender;
    }
    
    public void setGender(String gender) {
        if (gender != null && !gender.isEmpty()) {
            this.gender = gender;
        } else {
            throw new IllegalArgumentException("Gender cannot be empty.");
        }
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        if (email.contains(",")) {
            throw new IllegalArgumentException("Email cannot contain ',' character.");
        } else if (email.contains("@")) {
            this.email = email;
        }else if(email.isEmpty()){
            throw new IllegalArgumentException("Email cannot be empty.");
        }else{
            throw new IllegalArgumentException("Invalid email format.");
        }
    }
    
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        if (password.contains(",")) {
            throw new IllegalArgumentException("Password cannot contain ',' character.");
        } else if (password.isEmpty()) {
            throw new IllegalArgumentException("Password or confirm password cannot be empty.");
        }
        if (password.length() < 8) {
            throw new IllegalArgumentException("Password must be at least 8 characters long.");
        }
        this.password = password;
    }
    
    public String getRole(){
        return role;
    }
    
    public void setRole(String role) {
            this.role = role;
    }
    
    public String getApprovalStatus() {
        return Status;
    }
        
    public void setApprovalStatus(String approvalStatus) {
        this.Status = approvalStatus;
    }
    
    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
            this.roomType = roomType;
    }

    private boolean isValidDate(String dobString) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        dateFormat.setLenient(false);
        try {
            Date parsedDate = dateFormat.parse(dobString);
            return !parsedDate.after(new Date());
        } catch (ParseException e) {
            return false;
        }
    }
    
    private boolean ageChecker(String dobString) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        dateFormat.setLenient(false);
        try {
            Date birthDate = dateFormat.parse(dobString);
            Calendar birthCalendar = Calendar.getInstance();
            birthCalendar.setTime(birthDate);

            Calendar today = Calendar.getInstance();
            int age = today.get(Calendar.YEAR) - birthCalendar.get(Calendar.YEAR);
            if (today.get(Calendar.DAY_OF_YEAR) < birthCalendar.get(Calendar.DAY_OF_YEAR)) {
                age--;
            }
            return age >= 15 && age <= 100;
        } catch (ParseException e) {
            return false;
        }
    }
    
    class User {
        private String tpNumber;
        private String name;
        private String dateOfBirth;
        private String gender;
        private String email;
        private String password;
        private String role;
        private String roomType;
        private String approvalStatus;

        public User(String tpNumber, String name, String dateOfBirth, String gender, String email, String password, String role, String roomType, String approvalStatus) {
            this.tpNumber = tpNumber;
            this.name = name;
            this.dateOfBirth = dateOfBirth;
            this.gender = gender;
            this.email = email;
            this.password = password;
            this.role = role;
            this.roomType = roomType;
            this.approvalStatus = approvalStatus;
        }

        public String getTpNumber() {
            return tpNumber;
        }
        
        public void setTPNumber(String TP) {
            this.tpNumber = TP;
        } 

        public String getName() {
            return name;
        }
        
        public void setName(String Name){
            this.name = Name;
        }

        public String getDateOfBirth() {
            return dateOfBirth;
        }
        
        public void setDOB(String DOB){
            this.dateOfBirth = DOB;
        }

        public String getGender() {
            return gender;
        }
        
        public void setGender(String Gender){
            this.gender = Gender;
        }

        public String getEmail() {
            return email;
        }
        
        public void setEmail(String Email){
            this.email = Email;
        }
        
        public String getPassword(){
            return password;
        }
        
        public void setPassword(String pass){
            this.password = pass;
        }

        public String getRole() {
            return role;
        }
        
        public void setRole(String Role){
            this.role = Role;
        }

        public String getRoomType() {
            return roomType;
        }
        
        public void setRoom(String Room){
            this.roomType = Room;
        }
        
        public String getApprovalStatus() {
            return approvalStatus;
        }
        
        public void setApprovalStatus(String Status){
            this.approvalStatus = Status;
        }
        
    }
    
    public User getUserTP2() {
        return userTP2;
    }

    public void setUserTP2(User userTP2) {
        this.userTP2 = userTP2;
    }
    
    public UpdateStaff() {
        this("TP123456");
    }
    
    public UpdateStaff(String TP) {
        this.userTP1 = TP;
        initComponents();
        UpdateStaff();
    }
    
    public User matchTP(String tpNumber) {
        String filePath = "userData.txt";
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] userData = line.split(",");
                if (userData.length >= 9 && userData[0].equals(tpNumber)) { // Check TPNumber matches
                    return new User(
                            userData[0], // tpNumber
                            userData[1], // name
                            userData[2], // dateOfBirth
                            userData[3], // gender
                            userData[4], // email
                            userData[5], //password
                            userData[6], // role
                            userData[7], // roomType
                            userData[8]  // approvalStatus
                    );
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error reading file: " + e.getMessage(), "File Error", JOptionPane.ERROR_MESSAGE);
        }
        return null; 
    }
    
    private void updateUser() {
        String filePath = "userData.txt";
        StringBuilder updatedData = new StringBuilder();
        boolean updated = false;

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] userData = line.split(",");
                if (userData.length >= 9 && userData[0].equals(tpNumber)) { 
                    String updatedLine = String.join(",", tpNumber, name, dateOfBirth, gender, email, password, role, roomType, Status);
                    updatedData.append(updatedLine).append("\n");
                    updated = true; 
                } else {
                    updatedData.append(line).append("\n"); 
                }
            }

            if (updated) {
                try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
                    bw.write(updatedData.toString());
                }
            } else {
                JOptionPane.showMessageDialog(this, "User not found to update.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error reading or writing to file: " + e.getMessage(), "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void UpdateStaff() {
        this.setTitle("Update Personal Details");
        this.setSize(600,450);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        this.addWindowListener(new WindowAdapter() { 
            @Override
            public void windowClosing(WindowEvent e) {
                int choice = JOptionPane.showConfirmDialog(
                        UpdateStaff.this,
                        "Are you sure you want to exit?",
                        "Exit Confirmation",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

                if (choice == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });
        User userTP2 = matchTP(userTP1);
        setUserTP2(userTP2);
        
        if (userTP2 != null) {
            TP2.setText(userTP2.getTpNumber());
            Name2.setText(userTP2.getName());
            DOB2.setText(userTP2.getDateOfBirth());
            Gender2.setText(userTP2.getGender());
            Email2.setText(userTP2.getEmail());
            PW2.setText(userTP2.getPassword());
            TPTF.setText(userTP2.getTpNumber());
            NameTF.setText(userTP2.getName());
            try {
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
                Date date = dateFormat.parse(userTP2.getDateOfBirth()); 
                DOBTF.setDate(date);
            } catch (ParseException e) {
                JOptionPane.showMessageDialog(null, "Invalid date format: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
            GenderBox.setSelectedItem(userTP2.getGender());
            EmailTF.setText(userTP2.getEmail());
            PWTF.setText(userTP2.getPassword());
        } else {
            JOptionPane.showMessageDialog(this, "User not found!", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        this.setVisible(true);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Title = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        Email1 = new javax.swing.JLabel();
        EmailTF = new javax.swing.JTextField();
        NameTF = new javax.swing.JTextField();
        Name1 = new javax.swing.JLabel();
        DOB1 = new javax.swing.JLabel();
        Gender1 = new javax.swing.JLabel();
        GenderBox = new javax.swing.JComboBox<>();
        TP1 = new javax.swing.JLabel();
        Password = new javax.swing.JLabel();
        PWTF = new javax.swing.JTextField();
        DOBTF = new com.toedter.calendar.JDateChooser();
        TPTF = new javax.swing.JLabel();
        savebut = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Back = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        DOB2 = new javax.swing.JLabel();
        Gender2 = new javax.swing.JLabel();
        Email2 = new javax.swing.JLabel();
        TP = new javax.swing.JLabel();
        TP2 = new javax.swing.JLabel();
        Name = new javax.swing.JLabel();
        DOB = new javax.swing.JLabel();
        Gender = new javax.swing.JLabel();
        Email = new javax.swing.JLabel();
        Name2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        PW2 = new javax.swing.JLabel();
        Password1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Title.setFont(new java.awt.Font("MV Boli", 0, 20)); // NOI18N
        Title.setText("Update Personal Details");

        Email1.setText("Email:");

        Name1.setText("Name:");

        DOB1.setText("Date of Birth:");

        Gender1.setText("Gender:");

        GenderBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));
        GenderBox.setSelectedIndex(-1);

        TP1.setText("TP Number:");

        Password.setText("Password:");

        DOBTF.setDateFormatString("dd-MM-yyyy");

        TPTF.setText("TP000000");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(TP1)
                            .addComponent(Name1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(NameTF, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TPTF)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Gender1)
                            .addComponent(DOB1)
                            .addComponent(Email1)
                            .addComponent(Password))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(GenderBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(EmailTF, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
                            .addComponent(PWTF)
                            .addComponent(DOBTF, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TP1)
                    .addComponent(TPTF))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NameTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Name1))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(DOB1)
                    .addComponent(DOBTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(GenderBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Gender1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EmailTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Email1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Password)
                    .addComponent(PWTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34))
        );

        savebut.setText("Save");
        savebut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                savebutActionPerformed(evt);
            }
        });

        Back.setText("Back");
        Back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackActionPerformed(evt);
            }
        });

        DOB2.setText("2000-01-01");

        Gender2.setText("Unknown");

        Email2.setText("emailnotfound@gmail.com");

        TP.setText("TP:");

        TP2.setText("TP000000");

        Name.setText("Name:");

        DOB.setText("DOB:");

        Gender.setText("Gender:");

        Email.setText("Email:");

        Name2.setText("None");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("Current User Data:");

        PW2.setText("Unknown");

        Password1.setText("Password:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(DOB)
                        .addGap(18, 18, 18)
                        .addComponent(DOB2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(TP)
                        .addGap(18, 18, 18)
                        .addComponent(TP2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Password1)
                            .addComponent(Email)
                            .addComponent(Gender))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Gender2)
                            .addComponent(Email2)
                            .addComponent(PW2)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(Name)
                        .addGap(18, 18, 18)
                        .addComponent(Name2)))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TP)
                    .addComponent(TP2))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Name)
                    .addComponent(Name2))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(DOB)
                    .addComponent(DOB2))
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Gender)
                    .addComponent(Gender2))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Email)
                    .addComponent(Email2))
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(PW2)
                    .addComponent(Password1))
                .addGap(74, 74, 74))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 21, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Back)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(79, 79, 79)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(93, 93, 93)
                        .addComponent(Title))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(245, 245, 245)
                        .addComponent(savebut)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Back)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(Title)))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 271, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(savebut)
                .addGap(49, 49, 49))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void savebutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_savebutActionPerformed
        User userTP2 = matchTP(userTP1);
        setUserTP2(userTP2);
        try {
            setTPNumber(userTP1);
            setName(NameTF.getText());
            setDateOfBirth(((javax.swing.JTextField) DOBTF.getDateEditor().getUiComponent()).getText());
            setGender((String) GenderBox.getSelectedItem());
            setEmail(EmailTF.getText());
            setPassword(PWTF.getText());
            setRole("Staff");
            setRoomType("None");
            setApprovalStatus(userTP2.getApprovalStatus());

            updateUser();

            JOptionPane.showMessageDialog(this, "Update Details successful!");
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Validation Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_savebutActionPerformed

    private void BackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackActionPerformed
        Staff s = new Staff(userTP1);
        s.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BackActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UpdateStaff.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UpdateStaff.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UpdateStaff.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UpdateStaff.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UpdateStaff().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Back;
    private javax.swing.JLabel DOB;
    private javax.swing.JLabel DOB1;
    private javax.swing.JLabel DOB2;
    private com.toedter.calendar.JDateChooser DOBTF;
    private javax.swing.JLabel Email;
    private javax.swing.JLabel Email1;
    private javax.swing.JLabel Email2;
    private javax.swing.JTextField EmailTF;
    private javax.swing.JLabel Gender;
    private javax.swing.JLabel Gender1;
    private javax.swing.JLabel Gender2;
    private javax.swing.JComboBox<String> GenderBox;
    private javax.swing.JLabel Name;
    private javax.swing.JLabel Name1;
    private javax.swing.JLabel Name2;
    private javax.swing.JTextField NameTF;
    private javax.swing.JLabel PW2;
    private javax.swing.JTextField PWTF;
    private javax.swing.JLabel Password;
    private javax.swing.JLabel Password1;
    private javax.swing.JLabel TP;
    private javax.swing.JLabel TP1;
    private javax.swing.JLabel TP2;
    private javax.swing.JLabel TPTF;
    private javax.swing.JLabel Title;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton savebut;
    // End of variables declaration//GEN-END:variables
}
