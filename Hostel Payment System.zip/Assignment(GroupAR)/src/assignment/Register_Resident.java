/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package assignment;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import static javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE;

/**
 *
 * @author Asus
 */
public class Register_Resident extends javax.swing.JFrame {

    /**
     * Creates new form Register_Manager
     */
    private String tpNumber;
    private String name;
    private String dateOfBirth;
    private String gender;
    private String email;
    private String password;
    private String role;
    private String roomType;
    
    public Register_Resident() {
        initComponents();
        this.setTitle("Register Page (Resident)");
        this.setSize(500,400);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                int choice = JOptionPane.showConfirmDialog(
                        Register_Resident.this,
                        "Are you sure you want to exit?",
                        "Exit Confirmation",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

                if (choice == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });

        this.setVisible(true);
    }
    
    public String getTPNumber() {
        return tpNumber;
    }

    public void setTPNumber(String tpNumber) {
        if (tpNumber.matches("TP\\d{6}")) {
            this.tpNumber = tpNumber;
        } else if(tpNumber.equals("TP")){
            throw new IllegalArgumentException("TP Number cannot be empty.");
        } else{
            throw new IllegalArgumentException("Invalid TP Number format.");
        }
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        if (name.contains(",")) {
            throw new IllegalArgumentException("Name cannot contain ',' character.");
        } else if (!name.isEmpty()) {
            this.name = name;
        } else {
            throw new IllegalArgumentException("Name cannot be empty.");
        }
    }
    
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(String dobString) {
        if (dobString.isEmpty()){
            throw new IllegalArgumentException("Date of Birth cannot be empty");
        }
        if (!isValidDate(dobString)) {
            throw new IllegalArgumentException("Invalid date format or date is in the future.");
        }
        if (!ageChecker(dobString)) {
            throw new IllegalArgumentException("User must be at least 15 years old to register.");
        }
        this.dateOfBirth = dobString;
    }
    
    public String getGender() {
        return gender;
    }
    
    public void setGender(String gender) {
        if (gender != null && !gender.isEmpty()) {
            this.gender = gender;
        } else {
            throw new IllegalArgumentException("Gender cannot be empty.");
        }
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        if (email.contains(",")) {
            throw new IllegalArgumentException("Email cannot contain ',' character.");
        } else if (email.contains("@")) {
            this.email = email;
        }else if(email.isEmpty()){
            throw new IllegalArgumentException("Email cannot be empty.");
        }else{
            throw new IllegalArgumentException("Invalid email format.");
        }
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password, String confirmPassword) {
        if (password.contains(",") || confirmPassword.contains(",")) {
            throw new IllegalArgumentException("Password cannot contain ',' character.");
        } else if (password.isEmpty() || confirmPassword.isEmpty()) {
            throw new IllegalArgumentException("Password or confirm password cannot be empty.");
        }
        if (password.length() < 8) {
            throw new IllegalArgumentException("Password must be at least 8 characters long.");
        }
        if (!password.equals(confirmPassword)) {
            throw new IllegalArgumentException("Passwords do not match.");
        }
        this.password = password;
    }
    
    public String getRole(){
        return role;
    }
    
    public void setRole(String role){
        this.role = role;
    }
    
    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        if (roomType != null && !roomType.isEmpty()) {
            if(roomType.equals("R001") || roomType.equals("R002") || roomType.equals("R003")|| roomType.equals("R004"))
                this.roomType = roomType;
            else{
                throw new IllegalArgumentException("Invalid Room Type");
            }
        } else {
            throw new IllegalArgumentException("Room type cannot be empty.");
        }
    }

    private boolean isValidDate(String dobString) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        dateFormat.setLenient(false);
        try {
            Date parsedDate = dateFormat.parse(dobString);
            return !parsedDate.after(new Date()); 
        } catch (ParseException e) {
            return false;
        }
    }
    
    private boolean ageChecker(String dobString) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        dateFormat.setLenient(false);
        try {
            Date birthDate = dateFormat.parse(dobString);
            Calendar birthCalendar = Calendar.getInstance();
            birthCalendar.setTime(birthDate);

            Calendar today = Calendar.getInstance();
            int age = today.get(Calendar.YEAR) - birthCalendar.get(Calendar.YEAR);
            if (today.get(Calendar.DAY_OF_YEAR) < birthCalendar.get(Calendar.DAY_OF_YEAR)) {
                age--;
            }
            return age >= 15 && age <= 100;
        } catch (ParseException e) {
            return false;
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BACKBUT = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        Email = new javax.swing.JLabel();
        EmailTF = new javax.swing.JTextField();
        PW = new javax.swing.JLabel();
        PWTF = new javax.swing.JTextField();
        NameTF = new javax.swing.JTextField();
        Name = new javax.swing.JLabel();
        DOB = new javax.swing.JLabel();
        Gender = new javax.swing.JLabel();
        GenderBox = new javax.swing.JComboBox<>();
        TP = new javax.swing.JLabel();
        TPTF = new javax.swing.JTextField();
        Cpassword = new javax.swing.JLabel();
        CPWTF = new javax.swing.JTextField();
        RoomType = new javax.swing.JLabel();
        RoomTF = new javax.swing.JTextField();
        RoomBUT = new javax.swing.JButton();
        DOBTF = new com.toedter.calendar.JDateChooser();
        jLabel1 = new javax.swing.JLabel();
        OK = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        BACKBUT.setText("Back");
        BACKBUT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BACKBUTActionPerformed(evt);
            }
        });

        Email.setText("Email:");

        PW.setText("Password:");

        Name.setText("Name:");

        DOB.setText("Date of Birth:");

        Gender.setText("Gender:");

        GenderBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));
        GenderBox.setSelectedIndex(-1);

        TP.setText("TP Number:");

        TPTF.setText("TP");
        TPTF.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                TPTFKeyTyped(evt);
            }
        });

        Cpassword.setText("Confirm Password:");

        RoomType.setText("Room Type:");

        RoomBUT.setText(">");
        RoomBUT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RoomBUTActionPerformed(evt);
            }
        });

        DOBTF.setDateFormatString("dd-MM-yyyy");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(TP)
                                    .addComponent(Name))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(NameTF)
                                    .addComponent(TPTF, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(Gender)
                                    .addComponent(DOB)
                                    .addComponent(Email)
                                    .addComponent(PW)
                                    .addComponent(Cpassword))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(GenderBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(EmailTF)
                                    .addComponent(PWTF)
                                    .addComponent(CPWTF, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
                                    .addComponent(DOBTF, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(0, 27, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(RoomType)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(RoomTF)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(RoomBUT)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TP)
                    .addComponent(TPTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NameTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Name))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(DOB)
                    .addComponent(DOBTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(GenderBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Gender))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(EmailTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Email))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(PWTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(PW))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CPWTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Cpassword))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RoomTF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(RoomType)
                    .addComponent(RoomBUT))
                .addContainerGap(26, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(jPanel1);

        jLabel1.setFont(new java.awt.Font("MV Boli", 0, 20)); // NOI18N
        jLabel1.setText("Register Page (Resident)");

        OK.setText("Register");
        OK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OKActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(BACKBUT)
                .addGap(0, 424, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(121, 121, 121)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(64, 64, 64)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(204, 204, 204)
                        .addComponent(OK)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(BACKBUT)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(OK)
                .addContainerGap(63, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BACKBUTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BACKBUTActionPerformed
        Register1 register = new Register1();
        register.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BACKBUTActionPerformed

    private void OKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OKActionPerformed
        try {
            setTPNumber(TPTF.getText());
            setName(NameTF.getText());
            setDateOfBirth(((javax.swing.JTextField) DOBTF.getDateEditor().getUiComponent()).getText());
            setGender((String) GenderBox.getSelectedItem());
            setEmail(EmailTF.getText());
            setPassword(PWTF.getText(), CPWTF.getText());
            setRole("Resident");
            setRoomType(RoomTF.getText());

            String registrationData = getTPNumber() + "," +
                                      getName() + "," +
                                      getDateOfBirth() + "," +
                                      getGender() + "," +
                                      getEmail() + "," +
                                      getPassword() + "," +
                                      getRole() + "," +
                                      getRoomType() + "," +
                                      "Not Approved" + "\n";

            boolean isDuplicate = false;
            String filePath = "userData.txt";
            try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.startsWith(getTPNumber() + ",")) {
                        isDuplicate = true;
                        break;
                    }
                }
            } catch (IOException e) {
                System.err.println("Error reading file for duplicates: " + e.getMessage());
            }

            if (isDuplicate) {
                JOptionPane.showMessageDialog(
                        this, 
                        "TP Number already exists!", 
                        "Validation Error", 
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            try (FileWriter fw = new FileWriter(filePath, true);
                 BufferedWriter bw = new BufferedWriter(fw);
                 PrintWriter out = new PrintWriter(bw)) {
                out.print(registrationData);
            } catch (IOException ex) {
                Logger.getLogger(Register_Manager.class.getName()).log(Level.SEVERE, null, ex);
            }

            JOptionPane.showMessageDialog(this, "Registration successful!");
            LoginPage main = new LoginPage();
            main.setVisible(true);
            this.dispose();
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Validation Error", JOptionPane.ERROR_MESSAGE);
        }
            
    }//GEN-LAST:event_OKActionPerformed

    private void RoomBUTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RoomBUTActionPerformed
        ShowRoomType();
    }//GEN-LAST:event_RoomBUTActionPerformed

    private void TPTFKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TPTFKeyTyped
        String currentText = TPTF.getText();
        char typedChar = evt.getKeyChar();

        if (currentText.length() < 2 && !currentText.equals("TP")) {
            TPTF.setText("TP");
        }

        if (currentText.length() >= 8 || (!Character.isDigit(typedChar) && currentText.length() >= 2)) {
            evt.consume(); 
        }
    }//GEN-LAST:event_TPTFKeyTyped

    private void ShowRoomType() {
        RoomType roomSelectionPage = new RoomType(this);
        roomSelectionPage.setVisible(true);
    }
    
    public void SetRoomType(String RoomType) {
        RoomTF.setText(RoomType);
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Register_Manager.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Register_Manager.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Register_Manager.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Register_Manager.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Register_Manager().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BACKBUT;
    private javax.swing.JTextField CPWTF;
    private javax.swing.JLabel Cpassword;
    private javax.swing.JLabel DOB;
    private com.toedter.calendar.JDateChooser DOBTF;
    private javax.swing.JLabel Email;
    private javax.swing.JTextField EmailTF;
    private javax.swing.JLabel Gender;
    private javax.swing.JComboBox<String> GenderBox;
    private javax.swing.JLabel Name;
    private javax.swing.JTextField NameTF;
    private javax.swing.JButton OK;
    private javax.swing.JLabel PW;
    private javax.swing.JTextField PWTF;
    private javax.swing.JButton RoomBUT;
    private javax.swing.JTextField RoomTF;
    private javax.swing.JLabel RoomType;
    private javax.swing.JLabel TP;
    private javax.swing.JTextField TPTF;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
