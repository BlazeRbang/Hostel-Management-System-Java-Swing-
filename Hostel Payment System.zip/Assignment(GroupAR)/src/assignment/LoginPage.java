/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package assignment;

import java.awt.Font;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JOptionPane;

/**
 *
 * @author Asus
 */
public class LoginPage extends javax.swing.JFrame {

    private String tpNumber;
    private String password;
    private String role;
    
    public String getTPNumber() {
        return tpNumber;
    }

    public void setTPNumber(String tpNumber) {
        if (tpNumber.equals("TP")) {
            throw new IllegalArgumentException("TP Number cannot be empty.");
        }

        if (tpNumber.matches("TP\\d{6}")) {
            this.tpNumber = tpNumber;
        } else {
            throw new IllegalArgumentException("Invalid TP Number format.");
        }  
    }
    
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        if (password == null || password.isEmpty()) {
            throw new IllegalArgumentException("Password cannot be empty.");
        }
        if (password.length() < 8) {
            throw new IllegalArgumentException("Password must be at least 8 characters long.");
        }
        this.password = password;
    }
    
    public String getRole(){
        return role;
    }
    
    public void setRole(String role) {
        if (role != null && !role.isEmpty()) {
            this.role = role;
        }else {
            throw new IllegalArgumentException("Role cannot be empty.");
        }
    }
    
    public void readUserData(String tpNumber, String password) {
        String filePath = "userData.txt";
        boolean tpNumberFound = false;
        boolean passwordMatches = false;
        boolean roleMatches = false;
        boolean isApprove = false;

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] userData = line.split(",");
                if (userData.length >= 9 && userData[0].trim().equals(tpNumber.trim())) {
                    tpNumberFound = true;

                    if (userData[5].trim().equals(password.trim())) {
                        passwordMatches = true;

                        String storedRole = userData[6].trim();

                        if (storedRole.equals(getRole())) {
                            roleMatches = true;
                            
                            String approval = userData[8].trim();
                            
                            if (approval.equals("Approved")){
                                isApprove = true;
                                
                                JOptionPane.showMessageDialog(null, "Login successful! Welcome " + userData[1] + "!");
                                handleUserRole(tpNumber, storedRole);
                                return;
                            }
                        }
                    }
                    break;
                }
            }

            if (!tpNumberFound) {
                JOptionPane.showMessageDialog(null, "TP Number not found.", "Login Error", JOptionPane.ERROR_MESSAGE);
            } else if (!passwordMatches) {
                JOptionPane.showMessageDialog(null, "Incorrect password.", "Login Error", JOptionPane.ERROR_MESSAGE);
            } else if (!roleMatches) {
                JOptionPane.showMessageDialog(null, "Role mismatch.", "Login Error", JOptionPane.ERROR_MESSAGE);
            } else if (!isApprove) {
                JOptionPane.showMessageDialog(null, "Your account is pending approval.", "Pending Approval", JOptionPane.ERROR_MESSAGE);
            }

        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error reading file: " + e.getMessage(), "File Error", JOptionPane.ERROR_MESSAGE);
        }

    }
    
    private void handleUserRole(String tpNumber, String role) {
        switch (role) {
            case "Big Manager":
                BigManager BM = new BigManager(tpNumber, role);
                BM.setVisible(true);
                this.dispose();
                break;

            case "Assistant Manager":
                AssManager AM = new AssManager(tpNumber, role);
                AM.setVisible(true);
                this.dispose();
                break;

            case "Staff":
                Staff staff = new Staff(tpNumber);
                staff.setVisible(true);
                this.dispose();
                break;

            case "Resident":
                Resident resident = new Resident(tpNumber);
                resident.setVisible(true);
                this.dispose();
                break;

            default:
                JOptionPane.showMessageDialog(this, "Invalid role.", "Error", JOptionPane.ERROR_MESSAGE);
                break;
        }
    }
    
    public LoginPage() {
        initComponents();
        this.setTitle("APU");
        Title.setFont(new Font("MV Boli",Font.PLAIN,20));
        Title2.setFont(new Font("MV Boli",Font.PLAIN,20));
        this.setSize(500,400);
        this.setResizable(false);
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                int choice = JOptionPane.showConfirmDialog(LoginPage.this,
                        "Are you sure you want to exit?",
                        "Exit Confirmation",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

                if (choice == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });

        this.setVisible(true);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        Title = new javax.swing.JLabel();
        ID_TF = new javax.swing.JTextField();
        ID = new javax.swing.JLabel();
        Password = new javax.swing.JLabel();
        Role_selector = new javax.swing.JComboBox<>();
        Role = new javax.swing.JLabel();
        Login_but = new javax.swing.JButton();
        Register_but = new javax.swing.JButton();
        Title2 = new javax.swing.JLabel();
        jCheckBox1 = new javax.swing.JCheckBox();
        PW_TF = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Title.setFont(new java.awt.Font("MV Boli", 0, 20)); // NOI18N
        Title.setText("APU Hostel Management");

        ID_TF.setText("TP");
        ID_TF.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ID_TFKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                ID_TFKeyTyped(evt);
            }
        });

        ID.setText("TP Number:");

        Password.setText("Password:");

        Role_selector.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Big Manager", "Assistant Manager", "Staff", "Resident" }));
        Role_selector.setSelectedIndex(-1);
        Role_selector.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                Role_selectorKeyReleased(evt);
            }
        });

        Role.setText("Role:");

        Login_but.setText("Login");
        Login_but.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Login_butActionPerformed(evt);
            }
        });

        Register_but.setText("Register");
        Register_but.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Register_butActionPerformed(evt);
            }
        });

        Title2.setFont(new java.awt.Font("MV Boli", 0, 20)); // NOI18N
        Title2.setText("Fees Payment");

        jCheckBox1.setText("Show Password");
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(ID)
                                .addGap(18, 18, 18)
                                .addComponent(ID_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(Password)
                                .addGap(18, 18, 18)
                                .addComponent(PW_TF, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(Login_but)
                                .addGap(35, 35, 35)
                                .addComponent(Register_but))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addComponent(Title2)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addComponent(Title)
                .addGap(35, 35, 35))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(Role)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Role_selector, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jCheckBox1))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(Title)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Title2)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ID_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ID))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Password)
                    .addComponent(PW_TF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jCheckBox1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 19, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Role_selector, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Role))
                .addGap(33, 33, 33)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Login_but)
                    .addComponent(Register_but))
                .addGap(36, 36, 36))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(jLabel1)
                .addGap(55, 55, 55)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(103, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(288, 288, 288)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(97, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void Register_butActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Register_butActionPerformed
        Register1 register = new Register1();
        register.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_Register_butActionPerformed

    private void Login_butActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Login_butActionPerformed
        String user = ID_TF.getText();
        String pass = PW_TF.getText();
        String selectedRole = (String) Role_selector.getSelectedItem();

        try {
            setTPNumber(user); 
            setPassword(pass);  
            setRole(selectedRole); 
            readUserData(user, pass);

        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Login Error", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_Login_butActionPerformed

    private void Role_selectorKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_Role_selectorKeyReleased
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            Login_but.requestFocus();
        }
    }//GEN-LAST:event_Role_selectorKeyReleased

    private void ID_TFKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ID_TFKeyTyped
        String currentText = ID_TF.getText();
        char typedChar = evt.getKeyChar();

        if (currentText.length() < 2 && !currentText.equals("TP")) {
            ID_TF.setText("TP");
            return;
        }
        if (ID_TF.getCaretPosition() < 2) {
            evt.consume(); 
            return;
        }
        if (currentText.length() >= 8 || (!Character.isDigit(typedChar) && currentText.length() >= 2)) {
            evt.consume(); 
        }
    }//GEN-LAST:event_ID_TFKeyTyped

    private void ID_TFKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ID_TFKeyReleased
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            PW_TF.requestFocus();
        }
    }//GEN-LAST:event_ID_TFKeyReleased

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        if (jCheckBox1.isSelected()) {
            PW_TF.setEchoChar((char) 0); 
        } else {
            PW_TF.setEchoChar('*'); 
        }
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LoginPage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new LoginPage().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ID;
    private javax.swing.JTextField ID_TF;
    private javax.swing.JButton Login_but;
    private javax.swing.JPasswordField PW_TF;
    private javax.swing.JLabel Password;
    private javax.swing.JButton Register_but;
    private javax.swing.JLabel Role;
    private javax.swing.JComboBox<String> Role_selector;
    private javax.swing.JLabel Title;
    private javax.swing.JLabel Title2;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
