/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package assignment;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;
import static javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE;

/**
 *
 * @author Asus
 */
public class ApproveUser2 extends javax.swing.JFrame {
    private String userTP1;
    private User userTP2;
    private final String managerTP;
    private final String role;

    
    class User {
        private final String tpNumber;
        private final String name;
        private final String dateOfBirth;
        private final String gender;
        private final String email;
        private final String role;
        private final String roomType;
        private String approvalStatus;

        public User(String tpNumber, String name, String dateOfBirth, String gender, String email, String role, String roomType, String approvalStatus) {
            this.tpNumber = tpNumber;
            this.name = name;
            this.dateOfBirth = dateOfBirth;
            this.gender = gender;
            this.email = email;
            this.role = role;
            this.roomType = roomType;
            this.approvalStatus = approvalStatus;
        }

        public String getTpNumber() {
            return tpNumber;
        }

        public String getName() {
            return name;
        }

        public String getDateOfBirth() {
            return dateOfBirth;
        }

        public String getGender() {
            return gender;
        }

        public String getEmail() {
            return email;
        }

        public String getRole() {
            return role;
        }

        public String getRoomType() {
            return roomType;
        }
        
        public String getApprovalStatus() {
            return approvalStatus;
        }
        
        public void setApprovalStatus(String approvalStatus) {
            this.approvalStatus = approvalStatus;
        }
    }
    
    public User getUserTP2() {
        return userTP2;
    }

    // Setter method for userTP2
    public void setUserTP2(User userTP2) {
        this.userTP2 = userTP2;
    }
    
    public ApproveUser2() {
        this("TP123456", "TP123456", ""); // Default TP Number
    }
    
    public ApproveUser2(String id, String TP, String role) {
        this.userTP1 = id;
        this.managerTP = TP;
        this.role = role;
        initComponents();
        ApproveUser2();
    }
    
    public User matchTP(String tpNumber) {
        String filePath = "userData.txt";
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                // Split the line into fields
                String[] userData = line.split(",");
                if (userData.length >= 9 && userData[0].equals(tpNumber)) {
                    return new User(
                            userData[0], // tpNumber
                            userData[1], // name
                            userData[2], // dateOfBirth
                            userData[3], // gender
                            userData[4], // email
                            userData[6], // role
                            userData[7], // roomType
                            userData[8]  // approvalStatus
                    );
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error reading file: " + e.getMessage(), "File Error", JOptionPane.ERROR_MESSAGE);
        }
        return null;
    }
    
    private void updateUserApprovalStatus(User user, String newApprovalStatus) {
        String filePath = "userData.txt";
        File tempFile = new File("userData_temp.txt"); 

        try (BufferedReader br = new BufferedReader(new FileReader(filePath));
             BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile))) {

            String line;
            boolean userUpdated = false;

            while ((line = br.readLine()) != null) {
                String[] userData = line.split(",");

                if (userData.length >= 9 && userData[0].equals(user.getTpNumber())) {
                    userData[8] = newApprovalStatus; 
                    line = String.join(",", userData);
                    userUpdated = true;
                }

                bw.write(line);
                bw.newLine();
            }

            if (!userUpdated) {
                JOptionPane.showMessageDialog(this, "User not found in records.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            br.close();
            bw.close();

            File oldFile = new File(filePath);
            if (oldFile.delete()) {
                tempFile.renameTo(oldFile);
            }

        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating file: " + e.getMessage(), "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void ApproveUser2() {
        this.setTitle("Approve User");
        this.setSize(500,400);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        this.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                // Show a confirmation dialog
                int choice = JOptionPane.showConfirmDialog(
                        ApproveUser2.this,
                        "Are you sure you want to exit?",
                        "Exit Confirmation",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

                if (choice == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });
        
        User userTP2 = matchTP(userTP1);
        setUserTP2(userTP2);
        if (userTP2 != null) {
            TP2.setText(userTP2.getTpNumber());
            Name2.setText(userTP2.getName());
            DOB2.setText(userTP2.getDateOfBirth());
            Gender2.setText(userTP2.getGender());
            Email2.setText(userTP2.getEmail());
            Room2.setText(userTP2.getRoomType());
            Role2.setText(userTP2.getRole());
            
            if (userTP2.getRoomType().equals("None")){
                Room1.setVisible(false); 
                Room2.setVisible(false);
            } else {
                Room1.setVisible(true);
                Room2.setVisible(true);
            }
        } else {
            JOptionPane.showMessageDialog(this, "User not found!", "Error", JOptionPane.ERROR_MESSAGE);
        }
        this.setVisible(true);
    }
    
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Back = new javax.swing.JButton();
        Verification = new javax.swing.JLabel();
        Approval = new javax.swing.JComboBox<>();
        Confirm = new javax.swing.JButton();
        Title = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        DOB2 = new javax.swing.JLabel();
        Gender2 = new javax.swing.JLabel();
        Email2 = new javax.swing.JLabel();
        TP = new javax.swing.JLabel();
        TP2 = new javax.swing.JLabel();
        Name = new javax.swing.JLabel();
        DOB = new javax.swing.JLabel();
        Gender = new javax.swing.JLabel();
        Email = new javax.swing.JLabel();
        Name2 = new javax.swing.JLabel();
        Role1 = new javax.swing.JLabel();
        Role2 = new javax.swing.JLabel();
        Room1 = new javax.swing.JLabel();
        Room2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Back.setText("Back");
        Back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackActionPerformed(evt);
            }
        });

        Verification.setText("Verification:");

        Approval.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Approve", "Not Approve" }));
        Approval.setSelectedIndex(1);

        Confirm.setText("Confirm");
        Confirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConfirmActionPerformed(evt);
            }
        });

        Title.setFont(new java.awt.Font("MV Boli", 0, 20)); // NOI18N
        Title.setText("User Details");

        DOB2.setText("2000-01-01");

        Gender2.setText("Unknown");

        Email2.setText("emailnotfound@gmail.com");

        TP.setText("TP:");

        TP2.setText("TP000000");

        Name.setText("Name:");

        DOB.setText("DOB:");

        Gender.setText("Gender:");

        Email.setText("Email:");

        Name2.setText("None");

        Role1.setText("Role:");

        Role2.setText("Unknown");

        Room1.setText("Room:");

        Room2.setText("None");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(Room1)
                    .addComponent(Role1)
                    .addComponent(Email)
                    .addComponent(Gender)
                    .addComponent(DOB)
                    .addComponent(Name)
                    .addComponent(TP))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Gender2)
                    .addComponent(Email2)
                    .addComponent(Name2)
                    .addComponent(DOB2)
                    .addComponent(TP2)
                    .addComponent(Role2)
                    .addComponent(Room2))
                .addGap(37, 37, 37))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TP)
                    .addComponent(TP2))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Name)
                    .addComponent(Name2))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(DOB)
                    .addComponent(DOB2))
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Gender)
                    .addComponent(Gender2))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Email)
                    .addComponent(Email2))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Role1)
                    .addComponent(Role2))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Room1)
                    .addComponent(Room2))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(jPanel1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Back)
                        .addGap(111, 111, 111)
                        .addComponent(Title))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(123, 123, 123)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(Verification)
                                    .addGap(35, 35, 35)
                                    .addComponent(Approval, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(23, 23, 23)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(78, 78, 78)
                                .addComponent(Confirm)))))
                .addContainerGap(126, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(59, Short.MAX_VALUE)
                        .addComponent(Title))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Back)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Approval, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Verification))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(Confirm)
                .addGap(19, 19, 19))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackActionPerformed
        ApproveUser AU = new ApproveUser(managerTP, role);
        AU.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BackActionPerformed

    private void ConfirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConfirmActionPerformed
        if (userTP2 != null) {
            userTP2.setApprovalStatus((String) Approval.getSelectedItem());

            if (userTP2.getApprovalStatus().equals("Approve")) {
                int choice = JOptionPane.showConfirmDialog(
                        ApproveUser2.this,
                        "Are you sure you want to approve this user?",
                        "Approval Confirmation",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

                if (choice == JOptionPane.YES_OPTION) {
                    updateUserApprovalStatus(userTP2, "Approved");
                    JOptionPane.showMessageDialog(this, "Successfully approved" + userTP1, "Approval Status", JOptionPane.INFORMATION_MESSAGE);
                }
            } else if (userTP2.getApprovalStatus().equals("Not Approve")) {
                int choice = JOptionPane.showConfirmDialog(
                        ApproveUser2.this,
                        "Are you sure you want to not approve this user?",
                        "Approval Confirmation",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

                if (choice == JOptionPane.YES_OPTION) {
                    updateUserApprovalStatus(userTP2, "Not Approved");
                }
            }
        }
    }//GEN-LAST:event_ConfirmActionPerformed

    /**
     * @param args the command line arguments
     */
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ApproveUser2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ApproveUser2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ApproveUser2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ApproveUser2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ApproveUser2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> Approval;
    private javax.swing.JButton Back;
    private javax.swing.JButton Confirm;
    private javax.swing.JLabel DOB;
    private javax.swing.JLabel DOB2;
    private javax.swing.JLabel Email;
    private javax.swing.JLabel Email2;
    private javax.swing.JLabel Gender;
    private javax.swing.JLabel Gender2;
    private javax.swing.JLabel Name;
    private javax.swing.JLabel Name2;
    private javax.swing.JLabel Role1;
    private javax.swing.JLabel Role2;
    private javax.swing.JLabel Room1;
    private javax.swing.JLabel Room2;
    private javax.swing.JLabel TP;
    private javax.swing.JLabel TP2;
    private javax.swing.JLabel Title;
    private javax.swing.JLabel Verification;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
