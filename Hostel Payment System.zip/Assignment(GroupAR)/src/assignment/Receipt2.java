/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package assignment;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import javax.swing.JOptionPane;
import static javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE;

/**
 *
 * @author Asus
 */
public class Receipt2 extends javax.swing.JFrame {
    
    private String payID;
    private String staffTP;
    private String resident;
    private String recID;
    private String room;
    private String roomName;
    private String paid;
    private String payDate;
    
    public String getResident(){
        return resident;
    }
    
    public void setResident(String TP){
        this.resident = TP;
    }
    
    public String getrecID(){
        return recID;
    }
    
    public void setrecID(String receipt){
        this.recID = receipt;
    }
    
    public String getRoom(){
        return room;
    }
    
    public void setRoom(String roomType){
        this.room = roomType;
    }
    
    public String getRoomName(){
        return roomName;
    }
    
    public void setRoomName(String room){
        this.roomName = room;
    }
    
    public String getPaid(){
        return paid;
    }
    
    public void setPaid(String paidAmount){
        this.paid = paidAmount;
    }
    
    public String getDate(){
        return payDate;
    }
    
    public void setDate(String pDate){
        this.payDate = pDate;
    }
    
    private void loadPay() {
        String filePath = "Payment.txt";

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] payData = line.split(",");
                if (payData.length >= 5) {
                    
                    if (payData[0].trim().equals(payID)){
                        String tp = payData[1].trim();
                        String roomID = payData[2].trim();
                        String payAmount = payData[3].trim();
                        String payDate = payData[4].trim();
                        setResident(tp);
                        setPaid(payAmount);
                        setRoom(roomID);
                        setDate(payDate);
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading file: " + e.getMessage(), "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void loadRoom() {
        String filePath = "RoomType.txt";

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] roomData = line.split(",");
                if (roomData.length >= 6) {
                    
                    if (roomData[0].trim().equals(getRoom())){
                        String name = roomData[1].trim();
                        setRoomName(name);
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading file: " + e.getMessage(), "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void loadReceipt() {
        String filePath = "Receipt.txt";
        int maxID = 0;

        try {
            File file = new File(filePath);

            if (!file.exists()) {
                file.createNewFile();
            }

            try (Scanner reader = new Scanner(file)) {
                while (reader.hasNextLine()) {
                    String line = reader.nextLine().trim();
                    if (!line.isEmpty() && line.startsWith("RC")) {
                        String[] parts = line.split(",");
                        if (parts.length > 0) {
                            String numericPart = parts[0].substring(2);
                            try {
                                int currentID = Integer.parseInt(numericPart); 
                                maxID = Math.max(maxID, currentID); 
                            } catch (NumberFormatException e) {
                                System.out.println("Invalid numeric format in line: " + line);
                            }
                        }
                    }
                }
            }

            int newID = maxID + 1;
            String newRecID = String.format("RC%03d", newID); // Format as RC001, RC002, etc.

            setrecID(newRecID);

        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error handling the file.", "File Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }  
    }
    
    private void saveReceipt() {
        String filePath = "Receipt.txt";
        try (FileWriter writer = new FileWriter(filePath, true)) {
            String receiptDetails = getrecID() + "," +
                                    payID + "," +
                                    getDate() + "," +
                                    getRoom() + "," +
                                    getRoomName() + "," +
                                    getPaid() + "," +
                                    getResident() + "," +
                                    staffTP;
            writer.write(receiptDetails + "\n");
            JOptionPane.showMessageDialog(this, "Receipt generated successfully!\n Receipt ID: " + getrecID(), "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error writing to the file.", "File Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    
    private void modifyPaymentStatus() {
        String filePath = "Payment.txt";
        String targetID = payID;
        String updatedStatus = "Yes";
        File tempFile = new File("temp.txt"); 

        try (BufferedReader br = new BufferedReader(new FileReader(filePath));
             BufferedWriter bw = new BufferedWriter(new FileWriter(tempFile))) {

            String line;
            boolean recordUpdated = false;

            while ((line = br.readLine()) != null) {
                String[] fields = line.split(",");
                if (fields.length >= 6 && fields[0].equals(targetID)) {
                    // Change the status field
                    fields[fields.length - 1] = updatedStatus;
                    line = String.join(",", fields);
                    recordUpdated = true;
                }
                bw.write(line);
                bw.newLine();
            }

            if (!recordUpdated) {
                JOptionPane.showMessageDialog(null, "No matching record found.", "Update Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error processing file: " + e.getMessage(), "File Error", JOptionPane.ERROR_MESSAGE);
        }

        // Replace original file with the updated content
        if (tempFile.exists()) {
            File originalFile = new File(filePath);
            if (originalFile.delete() && tempFile.renameTo(originalFile)) {
                
            } else {
                JOptionPane.showMessageDialog(null, "Error updating file.", "File Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    public Receipt2() {
        this("TP123456", "TP123456");
    }
    
    public Receipt2(String ID, String Staff) {
        this.payID = ID;
        this.staffTP = Staff;
        initComponents();
        Receipt2();
    }
    
    public void Receipt2() {
        this.setTitle("Receipt");
        this.setSize(500,400);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        this.addWindowListener(new WindowAdapter() { 
            public void windowClosing(WindowEvent e) {
                int choice = JOptionPane.showConfirmDialog(Receipt2.this,
                        "Are you sure you want to exit?",
                        "Exit Confirmation",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

                if (choice == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });
        if (payID != null){
            loadPay();
            loadRoom();
            loadReceipt();
            ReceiptID.setText(getrecID());
            Date.setText(getDate());
            RoomID.setText(getRoom());
            RoomName.setText(getRoomName());
            Rent.setText("RM " + getPaid());
            TP.setText(getResident());
            Staff.setText(staffTP);
        }else{
            JOptionPane.showMessageDialog(this, "Payment Record not found!", "Error", JOptionPane.ERROR_MESSAGE);
        }
        this.setVisible(true);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Back = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        ReceiptID = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        Date = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        RoomID = new javax.swing.JLabel();
        RoomName = new javax.swing.JLabel();
        Rent = new javax.swing.JLabel();
        TP = new javax.swing.JLabel();
        Staff = new javax.swing.JLabel();
        Save = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Back.setText("Back");
        Back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("ASIA PASIFIC UNIVERSITY SDN BHD");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("OFFICIAL RECEIPT");

        jLabel3.setText("Receipt Number:");

        ReceiptID.setText("jLabel4");

        jLabel5.setText("Date:");

        Date.setText("jLabel6");

        jLabel4.setText("___________________________________________________________________________");

        jLabel6.setText("Room Type:");

        jLabel7.setText("Room Name:");

        jLabel8.setText("Paid Amount:");

        jLabel9.setText("REF No:");

        jLabel10.setText("Generated By:");

        jLabel11.setText("___________________________________________________________________________");

        RoomID.setText("jLabel4");

        RoomName.setText("jLabel4");

        Rent.setText("jLabel4");

        TP.setText("jLabel6");

        Staff.setText("jLabel6");

        Save.setText("Save");
        Save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Back)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel11))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addComponent(RoomID))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel7)
                        .addGap(18, 18, 18)
                        .addComponent(RoomName)))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(186, 186, 186))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel4)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(jLabel8)
                                    .addGap(18, 18, 18)
                                    .addComponent(Rent)))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel3)
                                    .addGap(18, 18, 18)
                                    .addComponent(ReceiptID)
                                    .addGap(143, 143, 143)
                                    .addComponent(jLabel5)
                                    .addGap(18, 18, 18)
                                    .addComponent(Date, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel10)
                                        .addComponent(jLabel9))
                                    .addGap(18, 18, 18)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(TP, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(Staff, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(136, 136, 136)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(207, 207, 207)
                        .addComponent(Save)))
                .addContainerGap(82, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(Back)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(ReceiptID)
                    .addComponent(jLabel5)
                    .addComponent(Date))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(RoomID)
                    .addComponent(jLabel9)
                    .addComponent(TP))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(RoomName))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(Rent)
                    .addComponent(jLabel10)
                    .addComponent(Staff))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel11)
                .addGap(33, 33, 33)
                .addComponent(Save)
                .addGap(0, 69, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveActionPerformed
        saveReceipt();
        modifyPaymentStatus();
        Receipt rc = new Receipt(staffTP);
        rc.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_SaveActionPerformed

    private void BackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackActionPerformed
        Receipt rc = new Receipt(staffTP);
        rc.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BackActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Receipt2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Receipt2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Receipt2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Receipt2.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Receipt2().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Back;
    private javax.swing.JLabel Date;
    private javax.swing.JLabel ReceiptID;
    private javax.swing.JLabel Rent;
    private javax.swing.JLabel RoomID;
    private javax.swing.JLabel RoomName;
    private javax.swing.JButton Save;
    private javax.swing.JLabel Staff;
    private javax.swing.JLabel TP;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    // End of variables declaration//GEN-END:variables
}
