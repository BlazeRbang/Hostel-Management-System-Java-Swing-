/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package assignment;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import static javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE;

/**
 *
 * @author Asus
 */
public class RoomType extends javax.swing.JFrame {
    private final Register_Resident mainPage;
    private String roomID;
    private String name;
    private String desc;
    private String squareFt;
    private String rate;
    private String deposit;
    private ArrayList<String[]> roomDataList = new ArrayList<>();
    
    public String getRoomID() {
        return roomID;
    }
        
    public void setRoomID(String ID) {
        this.roomID = ID;
    }
    
    public String getName() {
        return name;
    }
        
    public void setName(String name) {
        this.name = name;
    }
    
    public String getDesc() {
        return desc;
    }
        
    public void setDesc(String desc) {
        this.desc = desc;
    }
    
    public String getSqFt() {
        return squareFt;
    }
        
    public void setSqFt(String SqFt) {
        this.squareFt = SqFt;
    }
    
    public String getRate() {
        return rate;
    }
        
    public void setRate(String rate) {
        this.rate = rate;
    }
    
    public String getDep() {
        return deposit;
    }
        
    public void setDep(String Dep) {
        this.deposit = Dep;
    }
    
    public void loadRoomData(String filePath) {
        File file = new File(filePath);
        if (!file.exists()) {
            writeDefaultRoomData(filePath);
        }
        roomDataList.clear();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                roomDataList.add(line.split(","));
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error reading file: " + e.getMessage(), "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void writeDefaultRoomData(String filePath) {
        String[] roomDataArray = {
                "R001,En-Suite Single (Super Premium),Extra large room with fridge and table lamp,170+,RM 1400,RM 400",
                "R002,En-Suite Single (Premium),Large room with fridge and table lamp,150+,RM 1100,RM 400",
                "R003,En-Suite Single (Deluxe),Big room with fridge and table lamp,130+,RM 1000,RM 400",
                "R004,En-Suite Twin,Shared large room with fridge and table lamp,225+,RM 980,RM400"
        };

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (String roomData : roomDataArray) {
                writer.write(roomData);
                writer.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error creating file: " + e.getMessage(), "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void displayRoomData() {
        for (int i = 0; i < roomDataList.size(); i++) {
        String[] roomData = roomDataList.get(i);
            switch (i) {
                case 0:
                    ID1.setText(roomData[0]);
                    Name1.setText(roomData[1]);
                    Description1.setText(roomData[2]);
                    Size1.setText(roomData[3]);
                    Price1.setText(roomData[4]);
                    De1.setText(roomData[5]);
                    break;
                case 1:
                    ID2.setText(roomData[0]);
                    Name2.setText(roomData[1]);
                    Description2.setText(roomData[2]);
                    Size2.setText(roomData[3]);
                    Price2.setText(roomData[4]);
                    De2.setText(roomData[5]);
                    break;
                case 2:
                    ID3.setText(roomData[0]);
                    Name3.setText(roomData[1]);
                    Description3.setText(roomData[2]);
                    Size3.setText(roomData[3]);
                    Price3.setText(roomData[4]);
                    De3.setText(roomData[5]);
                    break;
                case 3:
                    ID4.setText(roomData[0]);
                    Name4.setText(roomData[1]);
                    Description4.setText(roomData[2]);
                    Size4.setText(roomData[3]);
                    Price4.setText(roomData[4]);
                    De4.setText(roomData[5]);
                    break;
                default:
                    break;
            }
        }
    }

    public RoomType(Register_Resident mainPage) {
        this.mainPage = mainPage;
        initComponents();
        this.setTitle("Room Type");
        this.setSize(500,400);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        
        loadRoomData("RoomType.txt");
        displayRoomData();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Back = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        RoomID1 = new javax.swing.JLabel();
        Name1 = new javax.swing.JLabel();
        RoomName1 = new javax.swing.JLabel();
        ID1 = new javax.swing.JLabel();
        Desc1 = new javax.swing.JLabel();
        Description1 = new javax.swing.JLabel();
        SqF1 = new javax.swing.JLabel();
        Size1 = new javax.swing.JLabel();
        Rate1 = new javax.swing.JLabel();
        Price1 = new javax.swing.JLabel();
        Deposit1 = new javax.swing.JLabel();
        De1 = new javax.swing.JLabel();
        Dottedline = new javax.swing.JLabel();
        Description2 = new javax.swing.JLabel();
        SqF2 = new javax.swing.JLabel();
        Size2 = new javax.swing.JLabel();
        Rate2 = new javax.swing.JLabel();
        Price2 = new javax.swing.JLabel();
        Deposit2 = new javax.swing.JLabel();
        RoomID2 = new javax.swing.JLabel();
        De2 = new javax.swing.JLabel();
        Name2 = new javax.swing.JLabel();
        RoomName2 = new javax.swing.JLabel();
        ID2 = new javax.swing.JLabel();
        Desc2 = new javax.swing.JLabel();
        Rate3 = new javax.swing.JLabel();
        Price3 = new javax.swing.JLabel();
        Deposit3 = new javax.swing.JLabel();
        RoomID3 = new javax.swing.JLabel();
        De3 = new javax.swing.JLabel();
        Name3 = new javax.swing.JLabel();
        RoomName3 = new javax.swing.JLabel();
        ID3 = new javax.swing.JLabel();
        Desc3 = new javax.swing.JLabel();
        Dottedline1 = new javax.swing.JLabel();
        Description3 = new javax.swing.JLabel();
        SqF3 = new javax.swing.JLabel();
        Size3 = new javax.swing.JLabel();
        Rate4 = new javax.swing.JLabel();
        Price4 = new javax.swing.JLabel();
        Deposit4 = new javax.swing.JLabel();
        RoomID4 = new javax.swing.JLabel();
        De4 = new javax.swing.JLabel();
        Name4 = new javax.swing.JLabel();
        RoomName4 = new javax.swing.JLabel();
        ID4 = new javax.swing.JLabel();
        Desc4 = new javax.swing.JLabel();
        Dottedline2 = new javax.swing.JLabel();
        Description4 = new javax.swing.JLabel();
        SqF4 = new javax.swing.JLabel();
        Size4 = new javax.swing.JLabel();
        hehe = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        RoomSelector = new javax.swing.JComboBox<>();
        Confirm = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Back.setText("Back");
        Back.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackActionPerformed(evt);
            }
        });

        RoomID1.setText("Room ID:");

        Name1.setText("En-Suite Single (Super Premium)");

        RoomName1.setText("Room Name:");

        ID1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ID1.setText("R001");

        Desc1.setText("Description:");

        Description1.setText("Extra large room with fridge and table lamp");

        SqF1.setText("Square Feet:");

        Size1.setText("170+");

        Rate1.setText("Rate Per Month:");

        Price1.setText("RM 1,400");

        Deposit1.setText("Deposit:");

        De1.setText("RM 400");

        Dottedline.setText("____________________________________________________");

        Description2.setText("Large room with fridge and table lamp");

        SqF2.setText("Square Feet:");

        Size2.setText("150+");

        Rate2.setText("Rate Per Month:");

        Price2.setText("bruh");

        Deposit2.setText("Deposit:");

        RoomID2.setText("Room ID:");

        De2.setText("bruh");

        Name2.setText("En-Suite Single (Premium)");

        RoomName2.setText("Room Name:");

        ID2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ID2.setText("R002");

        Desc2.setText("Description:");

        Rate3.setText("Rate Per Month:");

        Price3.setText("bruh");

        Deposit3.setText("Deposit:");

        RoomID3.setText("Room ID:");

        De3.setText("bruh");

        Name3.setText("En-Suite Single (Deluxe)");

        RoomName3.setText("Room Name:");

        ID3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ID3.setText("R003");

        Desc3.setText("Description:");

        Dottedline1.setText("___________________________________________________");

        Description3.setText("Big room with fridge and table lamp");

        SqF3.setText("Square Feet:");

        Size3.setText("130+");

        Rate4.setText("Rate Per Month:");

        Price4.setText("RM 980");

        Deposit4.setText("Deposit:");

        RoomID4.setText("Room ID:");

        De4.setText("RM 400");

        Name4.setText("En-Suite Twin");

        RoomName4.setText("Room Name:");

        ID4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        ID4.setText("R004");

        Desc4.setText("Description:");

        Dottedline2.setText("_________________________________________________");

        Description4.setText("Shared large room with fridge and table lamp");

        SqF4.setText("Square Feet:");

        Size4.setText("225+");

        hehe.setText("per person");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Deposit1)
                            .addComponent(Rate1)
                            .addComponent(SqF1)
                            .addComponent(Desc1)
                            .addComponent(RoomID1)
                            .addComponent(RoomName1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ID1)
                            .addComponent(Description1)
                            .addComponent(Size1)
                            .addComponent(Price1)
                            .addComponent(De1)
                            .addComponent(Name1)))
                    .addComponent(Dottedline)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Deposit2)
                            .addComponent(Rate2)
                            .addComponent(SqF2)
                            .addComponent(Desc2)
                            .addComponent(RoomID2)
                            .addComponent(RoomName2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ID2)
                            .addComponent(Description2)
                            .addComponent(Size2)
                            .addComponent(Price2)
                            .addComponent(De2)
                            .addComponent(Name2)))
                    .addComponent(Dottedline1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Deposit3)
                            .addComponent(Rate3)
                            .addComponent(SqF3)
                            .addComponent(Desc3)
                            .addComponent(RoomID3)
                            .addComponent(RoomName3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ID3)
                            .addComponent(Description3)
                            .addComponent(Size3)
                            .addComponent(Price3)
                            .addComponent(De3)
                            .addComponent(Name3)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Deposit4)
                            .addComponent(Rate4)
                            .addComponent(SqF4)
                            .addComponent(Desc4)
                            .addComponent(RoomID4)
                            .addComponent(RoomName4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ID4)
                            .addComponent(Description4)
                            .addComponent(Size4)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(Price4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(hehe))
                            .addComponent(De4)
                            .addComponent(Name4)))
                    .addComponent(Dottedline2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RoomID1)
                    .addComponent(ID1))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Name1)
                    .addComponent(RoomName1))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Desc1)
                    .addComponent(Description1))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SqF1)
                    .addComponent(Size1))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Rate1)
                    .addComponent(Price1))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Deposit1)
                    .addComponent(De1))
                .addGap(18, 18, 18)
                .addComponent(Dottedline)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RoomID2)
                    .addComponent(ID2))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Name2)
                    .addComponent(RoomName2))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Desc2)
                    .addComponent(Description2))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SqF2)
                    .addComponent(Size2))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Rate2)
                    .addComponent(Price2))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Deposit2)
                    .addComponent(De2))
                .addGap(18, 18, 18)
                .addComponent(Dottedline1)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RoomID3)
                    .addComponent(ID3))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Name3)
                    .addComponent(RoomName3))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Desc3)
                    .addComponent(Description3))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SqF3)
                    .addComponent(Size3))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Rate3)
                    .addComponent(Price3))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Deposit3)
                    .addComponent(De3))
                .addGap(18, 18, 18)
                .addComponent(Dottedline2)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RoomID4)
                    .addComponent(ID4))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Name4)
                    .addComponent(RoomName4))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Desc4)
                    .addComponent(Description4))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(SqF4)
                    .addComponent(Size4))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Rate4)
                    .addComponent(Price4)
                    .addComponent(hehe))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Deposit4)
                    .addComponent(De4))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jScrollPane1.setViewportView(jPanel1);

        jLabel4.setFont(new java.awt.Font("MV Boli", 0, 20)); // NOI18N
        jLabel4.setText("Room Type");

        RoomSelector.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "R001", "R002", "R003", "R004" }));
        RoomSelector.setSelectedIndex(-1);

        Confirm.setText("Confirm");
        Confirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConfirmActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(Back)
                .addGap(126, 126, 126)
                .addComponent(jLabel4)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(55, 55, 55)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 389, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(134, 134, 134)
                        .addComponent(RoomSelector, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(66, 66, 66)
                        .addComponent(Confirm)))
                .addContainerGap(56, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Back)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel4)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RoomSelector, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Confirm))
                .addGap(0, 64, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackActionPerformed
        Register_Resident RR = new Register_Resident();
        RR.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_BackActionPerformed

    private void ConfirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConfirmActionPerformed
        String room = (String)RoomSelector.getSelectedItem();
        mainPage.SetRoomType(room);
        if (room == null || room.isEmpty()) {
        JOptionPane.showMessageDialog(
            this,
            "No room selected. \nPlease select a room and try again.",
            "Selection Error",
            JOptionPane.ERROR_MESSAGE
        );
        return;
        }
        int choice = JOptionPane.showConfirmDialog(
            this,
            "You selected: " + room + "\nDo you want to confirm this selection?",
            "Confirm Selection",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );

        if (choice == JOptionPane.YES_OPTION) {
            if (mainPage != null) {
                mainPage.SetRoomType(room);
            }
            dispose();
        }
    }//GEN-LAST:event_ConfirmActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RoomType.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RoomType.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RoomType.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RoomType.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Register_Resident mainPage = new Register_Resident();
                new RoomType(mainPage).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Back;
    private javax.swing.JButton Confirm;
    private javax.swing.JLabel De1;
    private javax.swing.JLabel De2;
    private javax.swing.JLabel De3;
    private javax.swing.JLabel De4;
    private javax.swing.JLabel Deposit1;
    private javax.swing.JLabel Deposit2;
    private javax.swing.JLabel Deposit3;
    private javax.swing.JLabel Deposit4;
    private javax.swing.JLabel Desc1;
    private javax.swing.JLabel Desc2;
    private javax.swing.JLabel Desc3;
    private javax.swing.JLabel Desc4;
    private javax.swing.JLabel Description1;
    private javax.swing.JLabel Description2;
    private javax.swing.JLabel Description3;
    private javax.swing.JLabel Description4;
    private javax.swing.JLabel Dottedline;
    private javax.swing.JLabel Dottedline1;
    private javax.swing.JLabel Dottedline2;
    private javax.swing.JLabel ID1;
    private javax.swing.JLabel ID2;
    private javax.swing.JLabel ID3;
    private javax.swing.JLabel ID4;
    private javax.swing.JLabel Name1;
    private javax.swing.JLabel Name2;
    private javax.swing.JLabel Name3;
    private javax.swing.JLabel Name4;
    private javax.swing.JLabel Price1;
    private javax.swing.JLabel Price2;
    private javax.swing.JLabel Price3;
    private javax.swing.JLabel Price4;
    private javax.swing.JLabel Rate1;
    private javax.swing.JLabel Rate2;
    private javax.swing.JLabel Rate3;
    private javax.swing.JLabel Rate4;
    private javax.swing.JLabel RoomID1;
    private javax.swing.JLabel RoomID2;
    private javax.swing.JLabel RoomID3;
    private javax.swing.JLabel RoomID4;
    private javax.swing.JLabel RoomName1;
    private javax.swing.JLabel RoomName2;
    private javax.swing.JLabel RoomName3;
    private javax.swing.JLabel RoomName4;
    private javax.swing.JComboBox<String> RoomSelector;
    private javax.swing.JLabel Size1;
    private javax.swing.JLabel Size2;
    private javax.swing.JLabel Size3;
    private javax.swing.JLabel Size4;
    private javax.swing.JLabel SqF1;
    private javax.swing.JLabel SqF2;
    private javax.swing.JLabel SqF3;
    private javax.swing.JLabel SqF4;
    private javax.swing.JLabel hehe;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
